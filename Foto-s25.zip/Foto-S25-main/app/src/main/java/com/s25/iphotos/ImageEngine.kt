package com.s25.iphotos

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

data class EditParams(
    val exposure: Float = 0f,     // -100 a +100
    val brilliance: Float = 0f,   // -100 a +100 (stile iPhone)
    val highlights: Float = 0f,   // -100 a +100
    val shadows: Float = 0f,      // -100 a +100
    val contrast: Float = 0f,     // -100 a +100
    val saturation: Float = 0f,   // -100 a +100
    val warmth: Float = 0f,       // -100 a +100
    val sharpness: Float = 0f,    // 0 a +100
    val filterIndex: Int = 0,     // 0=Originale, 1=Vivido, 2=Vivido Caldo, 3=Drammatico, 4=Mono
    val rotation: Float = 0f,     // 0, 90, 180, 270
    val flipHorizontal: Boolean = false
)

object ImageEngine {

    val filterNames = listOf("Originale", "Vivido", "Caldo", "Drammatico", "Mono")

    fun applyEdits(source: Bitmap, params: EditParams): Bitmap {
        val matrix = Matrix().apply {
            if (params.rotation != 0f) postRotate(params.rotation)
            if (params.flipHorizontal) postScale(-1f, 1f, source.width / 2f, source.height / 2f)
        }
        val transformed = if (params.rotation != 0f || params.flipHorizontal) {
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        } else {
            source
        }

        val width = transformed.width
        val height = transformed.height
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val cm = ColorMatrix()

        when (params.filterIndex) {
            1 -> { // Vivido
                val sat = ColorMatrix().apply { setSaturation(1.28f) }
                val con = createContrastMatrix(1.12f)
                cm.postConcat(sat)
                cm.postConcat(con)
            }
            2 -> { // Vivido Caldo
                val sat = ColorMatrix().apply { setSaturation(1.22f) }
                val warm = createWarmthMatrix(22f)
                cm.postConcat(sat)
                cm.postConcat(warm)
            }
            3 -> { // Drammatico
                val sat = ColorMatrix().apply { setSaturation(0.82f) }
                val con = createContrastMatrix(1.28f)
                cm.postConcat(sat)
                cm.postConcat(con)
            }
            4 -> { // Mono
                val mono = ColorMatrix().apply { setSaturation(0f) }
                val con = createContrastMatrix(1.18f)
                cm.postConcat(mono)
                cm.postConcat(con)
            }
        }

        val expScale = 2f.pow(params.exposure / 65f)
        cm.postConcat(ColorMatrix(floatArrayOf(
            expScale, 0f, 0f, 0f, 0f,
            0f, expScale, 0f, 0f, 0f,
            0f, 0f, expScale, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )))

        val contrastFactor = 1f + (params.contrast / 110f)
        cm.postConcat(createContrastMatrix(contrastFactor))

        val satFactor = max(0f, 1f + (params.saturation / 100f))
        val satMatrix = ColorMatrix().apply { setSaturation(satFactor) }
        cm.postConcat(satMatrix)

        if (params.warmth != 0f) {
            cm.postConcat(createWarmthMatrix(params.warmth * 0.45f))
        }

        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(transformed, 0f, 0f, paint)

        if (params.brilliance != 0f || params.shadows != 0f || params.highlights != 0f) {
            applyToneCurve(result, params.brilliance / 100f, params.shadows / 100f, params.highlights / 100f)
        }

        return result
    }

    private fun createContrastMatrix(contrast: Float): ColorMatrix {
        val translate = (-.5f * contrast + .5f) * 255f
        return ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, translate,
            0f, contrast, 0f, 0f, translate,
            0f, 0f, contrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    private fun createWarmthMatrix(warmth: Float): ColorMatrix {
        return ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, warmth,
            0f, 1f, 0f, 0f, warmth * 0.25f,
            0f, 0f, 1f, 0f, -warmth,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    private fun applyToneCurve(bitmap: Bitmap, brilliance: Float, shadows: Float, highlights: Float) {
        val w = bitmap.width
        val h = bitmap.height
        val lut = IntArray(256)
        for (i in 0..255) {
            var v = i / 255f
            if (brilliance != 0f) {
                val midWeight = 4f * v * (1f - v)
                v += brilliance * 0.32f * midWeight
                v = v.coerceIn(0f, 1f)  // evita NaN (pixel neri) nel passo successivo
            }
            if (shadows != 0f) {
                val shadowWeight = (1f - v).pow(2.2f)
                v += shadows * 0.35f * shadowWeight
                v = v.coerceIn(0f, 1f)  // evita NaN (pixel neri) nel passo successivo
            }
            if (highlights != 0f) {
                val highWeight = v.pow(2.2f)
                v += highlights * 0.35f * highWeight
            }
            lut[i] = min(255, max(0, (v * 255f).toInt()))
        }

        // Lavora a strisce di 64 righe: con le foto da 50/200 MP del S25
        // un unico array con tutti i pixel faceva esaurire la memoria.
        val rowsPerChunk = 64
        val pixels = IntArray(w * rowsPerChunk)
        var y = 0
        while (y < h) {
            val rows = min(rowsPerChunk, h - y)
            bitmap.getPixels(pixels, 0, w, 0, y, w, rows)
            for (idx in 0 until w * rows) {
                val c = pixels[idx]
                val a = (c ushr 24) and 0xFF
                val r = lut[(c ushr 16) and 0xFF]
                val g = lut[(c ushr 8) and 0xFF]
                val b = lut[c and 0xFF]
                pixels[idx] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
            bitmap.setPixels(pixels, 0, w, 0, y, w, rows)
            y += rows
        }
    }

    fun saveToGallery(context: Context, bitmap: Bitmap): Uri? {
        val filename = "iPhoto_S25_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/iPhotos")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null

        val ok = try {
            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)
            } ?: false
        } catch (e: Exception) {
            false
        }
        if (!ok) {
            // Non lasciare file vuoti/rotti nella galleria
            resolver.delete(uri, null, null)
            return null
        }

        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }

    // =====================================================================
    // FOTO CON ZOOM: ritaglio oltre il limite della fotocamera + più definizione
    // =====================================================================

    /**
     * Migliora una foto appena scattata con lo zoom e la riscrive al suo posto.
     * extraZoom = parte di zoom fatta dall'app (oltre il massimo della fotocamera)
     * totalZoom = zoom totale scelto (es. 15x): più è alto, più si aumenta la nitidezza
     */
    fun enhanceZoomedPhoto(context: Context, uri: Uri, extraZoom: Float, totalZoom: Float): Boolean {
        return try {
            val resolver = context.contentResolver
            val source = ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver, uri)) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            var bmp = source.copy(Bitmap.Config.ARGB_8888, true) ?: return false
            if (bmp !== source) source.recycle()

            // 1) Ritaglio centrale per lo zoom oltre il limite della fotocamera
            if (extraZoom > 1.01f) {
                val cw = max(1, (bmp.width / extraZoom).toInt())
                val ch = max(1, (bmp.height / extraZoom).toInt())
                val crop = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch)
                // 2) Riporta la foto a una buona grandezza con un ingrandimento graduale
                //    (più passaggi piccoli = bordi più morbidi e meno "scalini")
                val targetLong = min(max(bmp.width, bmp.height), 4000)
                bmp.recycle()
                bmp = upscaleSmooth(crop, targetLong)
            }

            // 3) Più definizione: più forte con zoom alto
            val amount = when {
                totalZoom >= 10f -> 1.3f
                totalZoom >= 4f -> 0.9f
                else -> 0.5f
            }
            val threshold = if (totalZoom >= 10f) 6 else 3
            val sharp = sharpen(bmp, amount, threshold)
            if (sharp !== bmp) bmp.recycle()

            resolver.openOutputStream(uri, "wt")?.use { out ->
                sharp.compress(Bitmap.CompressFormat.JPEG, 97, out)
            }
            sharp.recycle()
            true
        } catch (e: Throwable) {
            false
        }
    }

    // Ingrandisce a passi di 1,5x al massimo fino a raggiungere il lato lungo voluto
    private fun upscaleSmooth(src: Bitmap, targetLong: Int): Bitmap {
        var current = src
        var long = max(current.width, current.height)
        while (long < targetLong) {
            val factor = min(1.5f, targetLong.toFloat() / long)
            val nw = max(1, (current.width * factor).toInt())
            val nh = max(1, (current.height * factor).toInt())
            val next = Bitmap.createScaledBitmap(current, nw, nh, true)
            if (current !== src) current.recycle()
            current = next
            long = max(current.width, current.height)
        }
        if (current !== src) src.recycle()
        return current
    }

    /**
     * Nitidezza "intelligente" (maschera di contrasto):
     * rinforza i bordi ma ignora le piccole differenze (soglia) per non aumentare il rumore.
     */
    private fun sharpen(src: Bitmap, amount: Float, threshold: Int): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 3 || h < 3) return src
        val inPx = IntArray(w * h)
        src.getPixels(inPx, 0, w, 0, 0, w, h)
        val outPx = IntArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            val up = if (y > 0) row - w else row
            val down = if (y < h - 1) row + w else row
            for (x in 0 until w) {
                val i = row + x
                val l = if (x > 0) i - 1 else i
                val r = if (x < w - 1) i + 1 else i
                val c = inPx[i]
                val n1 = inPx[up + x]
                val n2 = inPx[down + x]
                val n3 = inPx[l]
                val n4 = inPx[r]
                var res = c and 0xFF000000.toInt()
                var shift = 16
                while (shift >= 0) {
                    val cv = (c shr shift) and 0xFF
                    val avg = (((n1 shr shift) and 0xFF) + ((n2 shr shift) and 0xFF) +
                        ((n3 shr shift) and 0xFF) + ((n4 shr shift) and 0xFF)) shr 2
                    val diff = cv - avg
                    val v = if (diff > threshold || diff < -threshold) {
                        (cv + amount * diff).toInt().coerceIn(0, 255)
                    } else cv
                    res = res or (v shl shift)
                    shift -= 8
                }
                outPx[i] = res
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(outPx, 0, w, 0, 0, w, h)
        return out
    }
}
