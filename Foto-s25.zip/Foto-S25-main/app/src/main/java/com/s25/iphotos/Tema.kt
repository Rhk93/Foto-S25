package com.s25.iphotos

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

// ===== Colori in stile Apple (colori di sistema di iOS, versione scura) =====
val ACCENT_COLORS = listOf(
    Color(0xFFFFD60A), // Giallo
    Color(0xFFFF9F0A), // Arancione
    Color(0xFFFF453A), // Rosso
    Color(0xFFFF375F), // Rosa
    Color(0xFFBF5AF2), // Viola
    Color(0xFF5E5CE6), // Indaco
    Color(0xFF0A84FF), // Blu
    Color(0xFF64D2FF), // Azzurro
    Color(0xFF30D158), // Verde
    Color(0xFFE5E5EA)  // Argento
)
val ACCENT_NAMES = listOf(
    "Giallo", "Arancione", "Rosso", "Rosa", "Viola",
    "Indaco", "Blu", "Azzurro", "Verde", "Argento"
)

// Sfondo + colore delle superfici (pannelli, riquadri)
val BACKGROUND_NAMES = listOf("Nero", "Grafite", "Blu notte", "Grigio siderale")
private val BACKGROUNDS = listOf(Color(0xFF000000), Color(0xFF1C1C1E), Color(0xFF0B1426), Color(0xFF2B2D31))
private val SURFACES = listOf(Color(0xFF1C1C1E), Color(0xFF2C2C2E), Color(0xFF17233A), Color(0xFF3A3C41))

// Foto per riga nella galleria
val GRID_COLUMN_OPTIONS = listOf(3, 4, 5, 6)

/**
 * Impostazioni dell'aspetto dell'app.
 * Sono "osservabili": quando cambiano, tutte le schermate si aggiornano da sole.
 */
object AppTheme {
    var accentIndex by mutableStateOf(0)
    var backgroundIndex by mutableStateOf(0)
    var gridColumns by mutableStateOf(4)

    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        val p = context.getSharedPreferences("fotocamera", Context.MODE_PRIVATE)
        accentIndex = p.getInt("app_accento", 0).coerceIn(0, ACCENT_COLORS.size - 1)
        backgroundIndex = p.getInt("app_sfondo", 0).coerceIn(0, BACKGROUND_NAMES.size - 1)
        gridColumns = p.getInt("galleria_colonne", 4).let { if (it in GRID_COLUMN_OPTIONS) it else 4 }
        loaded = true
    }

    fun save(context: Context) {
        context.getSharedPreferences("fotocamera", Context.MODE_PRIVATE).edit()
            .putInt("app_accento", accentIndex)
            .putInt("app_sfondo", backgroundIndex)
            .putInt("galleria_colonne", gridColumns)
            .apply()
    }
}

// Colore principale dell'app (pulsanti, testi evidenziati)
val IosYellow: Color get() = ACCENT_COLORS[AppTheme.accentIndex]

// Testo da usare SOPRA il colore principale (nero o bianco, quello che si legge meglio)
val OnAccent: Color get() = if (IosYellow.luminance() > 0.45f) Color.Black else Color.White

// Sfondo e superfici
val IosBlack: Color get() = BACKGROUNDS[AppTheme.backgroundIndex]
val IosDarkGray: Color get() = SURFACES[AppTheme.backgroundIndex]

val IosBlue = Color(0xFF0A84FF)
