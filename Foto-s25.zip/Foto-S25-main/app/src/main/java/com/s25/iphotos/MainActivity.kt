package com.s25.iphotos

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

val IosBlack = Color(0xFF000000)
val IosDarkGray = Color(0xFF1C1C1E)
val IosYellow = Color(0xFFFFD60A)
val IosBlue = Color(0xFF0A84FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = IosBlack, surface = IosDarkGray)) {
                IPhotosApp()
            }
        }
    }
}

// Schermate dell'app
private const val SCR_HOME = "home"
private const val SCR_GRID = "grid"
private const val SCR_VIEWER = "viewer"
private const val SCR_EDITOR = "editor"

@Composable
fun IPhotosApp() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(hasPhotoPermission(context)) }
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var refreshKey by remember { mutableStateOf(0) }

    var screen by rememberSaveable { mutableStateOf(SCR_HOME) }
    var viewerIndex by rememberSaveable { mutableStateOf(0) }
    var viewerFromGrid by rememberSaveable { mutableStateOf(false) }
    var editUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        hasPermission = hasPhotoPermission(context)
    }

    LaunchedEffect(hasPermission, refreshKey) {
        if (!hasPermission) {
            launcher.launch(PHOTO_PERMISSIONS)
        } else {
            photos = withContext(Dispatchers.IO) { loadGalleryPhotos(context) }
        }
    }

    // Fotocamera: usa l'app Fotocamera Samsung del S25 (massima qualità).
    // Dopo lo scatto si torna qui e l'anteprima mostra la nuova foto.
    var pendingCameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val shot = pendingCameraUri
        pendingCameraUri = null
        if (shot != null) {
            if (success) {
                refreshKey++
            } else {
                // Scatto annullato: elimina il file vuoto
                try { context.contentResolver.delete(shot, null, null) } catch (_: Exception) {}
            }
        }
    }
    val openCamera: () -> Unit = {
        val newUri = createCameraUri(context)
        if (newUri == null) {
            Toast.makeText(context, "Impossibile preparare la foto", Toast.LENGTH_SHORT).show()
        } else {
            pendingCameraUri = newUri
            try {
                cameraLauncher.launch(newUri)
            } catch (e: Exception) {
                pendingCameraUri = null
                try { context.contentResolver.delete(newUri, null, null) } catch (_: Exception) {}
                Toast.makeText(context, "Fotocamera non disponibile", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = IosBlack) {
        if (!hasPermission) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Button(
                    onClick = { launcher.launch(PHOTO_PERMISSIONS) },
                    colors = ButtonDefaults.buttonColors(containerColor = IosBlue)
                ) {
                    Text("Consenti accesso alle Foto", color = Color.White)
                }
            }
        } else when (screen) {
            SCR_GRID -> {
                BackHandler { screen = SCR_HOME }
                GalleryGridScreen(
                    photos = photos,
                    onBack = { screen = SCR_HOME },
                    onPhotoClick = { index ->
                        viewerIndex = index
                        viewerFromGrid = true
                        screen = SCR_VIEWER
                    }
                )
            }

            SCR_VIEWER -> {
                val back = { screen = if (viewerFromGrid) SCR_GRID else SCR_HOME }
                BackHandler { back() }
                if (photos.isEmpty()) {
                    LaunchedEffect(Unit) { back() }
                } else {
                    PhotoViewerScreen(
                        photos = photos,
                        startIndex = viewerIndex.coerceIn(0, photos.size - 1),
                        onBack = back,
                        onPageChanged = { viewerIndex = it },
                        onEdit = { uri ->
                            editUri = uri
                            screen = SCR_EDITOR
                        }
                    )
                }
            }

            SCR_EDITOR -> {
                val uri = editUri
                if (uri == null) {
                    LaunchedEffect(Unit) { screen = SCR_VIEWER }
                } else {
                    PhotoEditorScreen(
                        uri = uri,
                        onBack = { screen = SCR_VIEWER },
                        onSaved = {
                            // La foto modificata è la più recente: la mostra subito
                            viewerIndex = 0
                            refreshKey++
                            screen = SCR_VIEWER
                        }
                    )
                }
            }

            else -> HomeScreen(
                lastPhoto = photos.firstOrNull(),
                photoCount = photos.size,
                onCameraClick = openCamera,
                onOpenLast = {
                    if (photos.isNotEmpty()) {
                        viewerIndex = 0
                        viewerFromGrid = false
                        screen = SCR_VIEWER
                    }
                },
                onOpenGallery = { screen = SCR_GRID }
            )
        }
    }
}

// Schermata iniziale: ultima foto in grande, e in basso
// anteprima piccola + pulsante di scatto + accesso a tutte le foto
@Composable
fun HomeScreen(
    lastPhoto: Uri?,
    photoCount: Int,
    onCameraClick: () -> Unit,
    onOpenLast: () -> Unit,
    onOpenGallery: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Text(
            text = "Foto S25",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(IosDarkGray)
                .clickable(enabled = lastPhoto != null) { onOpenLast() },
            contentAlignment = Alignment.Center
        ) {
            if (lastPhoto != null) {
                AsyncImage(
                    model = lastPhoto,
                    contentDescription = "Ultima foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text("Nessuna foto: scattane una!", color = Color.Gray, fontSize = 16.sp)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Anteprima piccola dell'ultima foto: apre tutte le foto
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(IosDarkGray)
                    .border(2.dp, Color.White, RoundedCornerShape(12.dp))
                    .clickable { onOpenGallery() },
                contentAlignment = Alignment.Center
            ) {
                if (lastPhoto != null) {
                    AsyncImage(
                        model = lastPhoto,
                        contentDescription = "Tutte le foto",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = "Tutte le foto", tint = Color.Gray)
                }
            }

            // Pulsante di scatto
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .border(4.dp, Color.White, CircleShape)
                    .padding(8.dp)
                    .clip(CircleShape)
                    .background(IosYellow)
                    .clickable { onCameraClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.PhotoCamera,
                    contentDescription = "Scatta foto",
                    tint = Color.Black,
                    modifier = Modifier.size(30.dp)
                )
            }

            // Numero di foto (stessa larghezza dell'anteprima, per centrare lo scatto)
            Box(modifier = Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                Text("$photoCount", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

// Tutte le foto in griglia
@Composable
fun GalleryGridScreen(photos: List<Uri>, onBack: () -> Unit, onPhotoClick: (Int) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Indietro", tint = IosYellow)
            }
            Text(
                text = "Libreria",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${photos.size} foto",
                color = Color.LightGray,
                fontSize = 13.sp,
                modifier = Modifier.padding(end = 12.dp)
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
        ) {
            itemsIndexed(photos) { index, uri ->
                AsyncImage(
                    model = uri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clickable { onPhotoClick(index) }
                )
            }
        }
    }
}

// Visualizzatore a schermo intero: si scorre tra le foto,
// e con "Modifica" si apre l'editor
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PhotoViewerScreen(
    photos: List<Uri>,
    startIndex: Int,
    onBack: () -> Unit,
    onPageChanged: (Int) -> Unit,
    onEdit: (Uri) -> Unit
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = startIndex) { photos.size }

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    Box(modifier = Modifier.fillMaxSize().background(IosBlack)) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            AsyncImage(
                model = photos[page],
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.5f))
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Indietro", tint = IosYellow)
            }
            Text(
                text = "${pagerState.currentPage + 1} di ${photos.size}",
                color = Color.White,
                fontSize = 15.sp
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.5f))
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                val uri = photos.getOrNull(pagerState.currentPage) ?: return@IconButton
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    context.startActivity(Intent.createChooser(send, "Condividi foto"))
                } catch (_: Exception) {}
            }) {
                Icon(Icons.Default.Share, contentDescription = "Condividi", tint = Color.White)
            }

            Button(
                onClick = {
                    photos.getOrNull(pagerState.currentPage)?.let { onEdit(it) }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IosYellow),
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.Black)
                Spacer(Modifier.width(8.dp))
                Text("Modifica", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

enum class ToolTab { ADJUST, FILTERS, CROP }

data class AdjustOption(
    val id: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun PhotoEditorScreen(uri: Uri, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previewSource by remember { mutableStateOf<Bitmap?>(null) }
    var editedPreview by remember { mutableStateOf<Bitmap?>(null) }
    var editParams by remember { mutableStateOf(EditParams()) }
    var showOriginalHold by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(ToolTab.ADJUST) }
    var selectedAdjustId by remember { mutableStateOf("brilliance") }
    var isSaving by remember { mutableStateOf(false) }

    // Il tasto "indietro" del telefono torna alla galleria invece di chiudere l'app
    BackHandler(enabled = !isSaving) { onBack() }

    val adjustOptions = remember {
        listOf(
            AdjustOption("exposure", "Esposizione", Icons.Default.Exposure),
            AdjustOption("brilliance", "Brillantezza", Icons.Default.AutoAwesome),
            AdjustOption("highlights", "Alte luci", Icons.Default.WbSunny),
            AdjustOption("shadows", "Ombre", Icons.Default.BrightnessLow),
            AdjustOption("contrast", "Contrasto", Icons.Default.Contrast),
            AdjustOption("saturation", "Saturazione", Icons.Default.Palette),
            AdjustOption("warmth", "Calore", Icons.Default.Thermostat)
        )
    }

    LaunchedEffect(uri) {
        val ok = withContext(Dispatchers.IO) {
            try {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                val full = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
                val scale = minOf(1400f / full.width, 1400f / full.height, 1f)
                val preview = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        full,
                        maxOf(1, (full.width * scale).toInt()),
                        maxOf(1, (full.height * scale).toInt()),
                        true
                    )
                } else full
                originalBitmap = full
                previewSource = preview
                true
            } catch (e: Throwable) {
                false
            }
        }
        if (!ok) {
            Toast.makeText(context, "Impossibile aprire questa foto", Toast.LENGTH_SHORT).show()
            onBack()
        }
    }

    LaunchedEffect(previewSource, editParams) {
        val src = previewSource ?: return@LaunchedEffect
        editedPreview = withContext(Dispatchers.Default) {
            ImageEngine.applyEdits(src, editParams)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Annulla",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onBack() }
            )

            if (editParams != EditParams()) {
                Text(
                    text = "Ripristina",
                    color = IosYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { editParams = EditParams() }
                )
            }

            Button(
                onClick = {
                    val full = originalBitmap ?: return@Button
                    isSaving = true
                    val params = editParams
                    scope.launch {
                        val saved = withContext(Dispatchers.IO) {
                            try {
                                val finalBmp = ImageEngine.applyEdits(full, params)
                                ImageEngine.saveToGallery(context, finalBmp) != null
                            } catch (e: Throwable) {
                                false
                            }
                        }
                        isSaving = false
                        if (saved) {
                            Toast.makeText(context, "Salvata nella Galleria", Toast.LENGTH_SHORT).show()
                            onSaved()
                        } else {
                            Toast.makeText(context, "Errore durante il salvataggio", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = IosYellow),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = if (isSaving) "..." else "Fine",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            showOriginalHold = true
                            tryAwaitRelease()
                            showOriginalHold = false
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            val displayBmp = if (showOriginalHold) previewSource else editedPreview
            displayBmp?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (showOriginalHold) {
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                ) {
                    Text(
                        "ORIGINALE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        when (activeTab) {
            ToolTab.ADJUST -> {
                val currentValue = getParamValue(editParams, selectedAdjustId)
                val currentLabel = adjustOptions.find { it.id == selectedAdjustId }?.label ?: ""

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        items(adjustOptions) { opt ->
                            val value = getParamValue(editParams, opt.id)
                            val isSelected = opt.id == selectedAdjustId
                            val isModified = value != 0f

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable { selectedAdjustId = opt.id }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color.White else IosDarkGray)
                                        .border(
                                            width = if (isModified && !isSelected) 2.dp else 0.dp,
                                            color = if (isModified) IosYellow else Color.Transparent,
                                            shape = CircleShape
                                        )
                                ) {
                                    Icon(
                                        imageVector = opt.icon,
                                        contentDescription = opt.label,
                                        tint = if (isSelected) Color.Black else Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = if (isModified) "${value.roundToInt()}" else opt.label,
                                    color = if (isSelected) IosYellow else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Text(
                        text = "${currentLabel.uppercase()}  ${currentValue.roundToInt()}",
                        color = if (currentValue != 0f) IosYellow else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IosRulerSlider(
                        value = currentValue,
                        onValueChange = { newVal ->
                            editParams = updateParamValue(editParams, selectedAdjustId, newVal)
                        }
                    )
                }
            }

            ToolTab.FILTERS -> {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(ImageEngine.filterNames) { index, name ->
                        val selected = editParams.filterIndex == index
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                editParams = editParams.copy(filterIndex = index)
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(IosDarkGray)
                                    .border(
                                        width = if (selected) 2.dp else 0.dp,
                                        color = IosYellow,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = name.take(3).uppercase(),
                                    color = if (selected) IosYellow else Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = name,
                                color = if (selected) IosYellow else Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            ToolTab.CROP -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 26.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = {
                            editParams = editParams.copy(rotation = (editParams.rotation + 90f) % 360f)
                        }
                    ) {
                        Icon(Icons.Default.RotateRight, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Ruota 90°", color = Color.White)
                    }
                    OutlinedButton(
                        onClick = {
                            editParams = editParams.copy(flipHorizontal = !editParams.flipHorizontal)
                        }
                    ) {
                        Icon(Icons.Default.Flip, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Rifletti", color = Color.White)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BottomTabItem("Regola", Icons.Default.Tune, activeTab == ToolTab.ADJUST) {
                activeTab = ToolTab.ADJUST
            }
            BottomTabItem("Filtri", Icons.Default.FilterVintage, activeTab == ToolTab.FILTERS) {
                activeTab = ToolTab.FILTERS
            }
            BottomTabItem("Ritaglia", Icons.Default.CropRotate, activeTab == ToolTab.CROP) {
                activeTab = ToolTab.CROP
            }
        }
    }
}

@Composable
fun BottomTabItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) IosYellow else Color.Gray)
        Spacer(Modifier.height(2.dp))
        Text(label, color = if (selected) IosYellow else Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun IosRulerSlider(value: Float, onValueChange: (Float) -> Unit) {
    val currentVal by rememberUpdatedState(value)
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 24.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    val delta = (dragAmount / size.width) * 200f
                    onValueChange((currentVal + delta).coerceIn(-100f, 100f))
                }
            }
    ) {
        val centerX = size.width / 2f
        val step = size.width / 40f
        val offsetPx = (value / 100f) * (size.width / 2.2f)

        for (i in -20..20) {
            val x = centerX + (i * step) + offsetPx
            if (x in 0f..size.width) {
                val isMajor = i % 5 == 0
                drawLine(
                    color = if (i == 0) IosYellow else Color.DarkGray,
                    start = Offset(x, if (isMajor) 14f else 22f),
                    end = Offset(x, size.height - 14f),
                    strokeWidth = if (i == 0) 4f else 2f
                )
            }
        }
        drawLine(
            color = Color.White,
            start = Offset(centerX, 6f),
            end = Offset(centerX, size.height - 6f),
            strokeWidth = 5f
        )
    }
}

private fun getParamValue(p: EditParams, id: String): Float = when (id) {
    "exposure" -> p.exposure
    "brilliance" -> p.brilliance
    "highlights" -> p.highlights
    "shadows" -> p.shadows
    "contrast" -> p.contrast
    "saturation" -> p.saturation
    "warmth" -> p.warmth
    else -> 0f
}

private fun updateParamValue(p: EditParams, id: String, v: Float): EditParams = when (id) {
    "exposure" -> p.copy(exposure = v)
    "brilliance" -> p.copy(brilliance = v)
    "highlights" -> p.copy(highlights = v)
    "shadows" -> p.copy(shadows = v)
    "contrast" -> p.copy(contrast = v)
    "saturation" -> p.copy(saturation = v)
    "warmth" -> p.copy(warmth = v)
    else -> p
}

private val PHOTO_PERMISSIONS = arrayOf(
    Manifest.permission.READ_MEDIA_IMAGES,
    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
)

// Su Android 14/15 l'utente può scegliere "Seleziona foto": in quel caso
// è concesso solo READ_MEDIA_VISUAL_USER_SELECTED, e va bene lo stesso.
private fun hasPhotoPermission(context: android.content.Context): Boolean =
    PHOTO_PERMISSIONS.any {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

// Crea il posto in Galleria (DCIM/Foto S25) dove la fotocamera salva lo scatto
private fun createCameraUri(context: android.content.Context): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "S25_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/Foto S25")
    }
    return try {
        context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    } catch (e: Exception) {
        null
    }
}

private fun loadGalleryPhotos(context: android.content.Context): List<Uri> {
    val uris = mutableListOf<Uri>()
    val projection = arrayOf(MediaStore.Images.Media._ID)
    val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
    context.contentResolver.query(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        projection,
        null,
        null,
        sortOrder
    )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idColumn)
            uris.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id))
        }
    }
    return uris
}
