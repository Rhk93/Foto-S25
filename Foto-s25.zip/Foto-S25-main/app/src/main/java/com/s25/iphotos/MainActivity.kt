package com.s25.iphotos

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// I colori (IosYellow, IosBlack, ...) sono in Tema.kt e si cambiano dalle impostazioni

// Una foto o un video della galleria
data class GalleryItem(val uri: Uri, val isVideo: Boolean, val durationMs: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        AppTheme.load(this)
        // Lo schermo resta acceso mentre si usa la fotocamera
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = IosBlack, surface = IosDarkGray)) {
                IPhotosApp()
            }
        }
    }
}

// Schermate dell'app
private const val SCR_CAMERA = "camera"
private const val SCR_GRID = "grid"
private const val SCR_VIEWER = "viewer"
private const val SCR_EDITOR = "editor"

@Composable
fun IPhotosApp() {
    val context = LocalContext.current
    var hasCamera by remember { mutableStateOf(hasCameraPermission(context)) }
    var items by remember { mutableStateOf<List<GalleryItem>>(emptyList()) }
    var refreshKey by remember { mutableStateOf(0) }

    var screen by rememberSaveable { mutableStateOf(SCR_CAMERA) }
    var viewerIndex by rememberSaveable { mutableStateOf(0) }
    var editUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    // Chiede tutti i permessi all'avvio: fotocamera, microfono e galleria
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        hasCamera = hasCameraPermission(context)
        refreshKey++
    }

    LaunchedEffect(Unit) {
        if (ALL_PERMISSIONS.any {
                ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
            }) {
            launcher.launch(ALL_PERMISSIONS)
        }
    }

    LaunchedEffect(refreshKey) {
        items = withContext(Dispatchers.IO) { loadGalleryItems(context) }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = IosBlack) {
        when (screen) {
            SCR_GRID -> {
                BackHandler { screen = SCR_CAMERA }
                GalleryGridScreen(
                    items = items,
                    onBack = { screen = SCR_CAMERA },
                    onItemClick = { index ->
                        viewerIndex = index
                        screen = SCR_VIEWER
                    }
                )
            }

            SCR_VIEWER -> {
                BackHandler { screen = SCR_GRID }
                if (items.isEmpty()) {
                    LaunchedEffect(Unit) { screen = SCR_GRID }
                } else {
                    MediaViewerScreen(
                        items = items,
                        startIndex = viewerIndex.coerceIn(0, items.size - 1),
                        onBack = { screen = SCR_GRID },
                        onPageChanged = { viewerIndex = it },
                        onEdit = { uri ->
                            editUri = uri
                            screen = SCR_EDITOR
                        }
                    )
                }
            }

            SCR_EDITOR -> {
                val uri = editUri
                if (uri == null) {
                    LaunchedEffect(Unit) { screen = SCR_VIEWER }
                } else {
                    PhotoEditorScreen(
                        uri = uri,
                        onBack = { screen = SCR_VIEWER },
                        onSaved = {
                            // La foto modificata è la più recente: la mostra subito
                            viewerIndex = 0
                            refreshKey++
                            screen = SCR_VIEWER
                        }
                    )
                }
            }

            else -> {
                if (!hasCamera) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Button(
                            onClick = { launcher.launch(ALL_PERMISSIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = IosBlue)
                        ) {
                            Text("Consenti accesso alla fotocamera", color = Color.White)
                        }
                    }
                } else {
                    CameraScreen(
                        lastItem = items.firstOrNull(),
                        onOpenGallery = { screen = SCR_GRID },
                        onCaptured = { refreshKey++ }
                    )
                }
            }
        }
    }
}

// Tutte le foto e i video in griglia
@Composable
fun GalleryGridScreen(items: List<GalleryItem>, onBack: () -> Unit, onItemClick: (Int) -> Unit) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.PhotoCamera, contentDescription = "Fotocamera", tint = IosYellow)
            }
            Text(
                text = "Libreria",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${items.size} elementi",
                color = Color.LightGray,
                fontSize = 13.sp,
                modifier = Modifier.padding(end = 12.dp)
            )
        }

        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nessuna foto o video", color = Color.Gray)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(AppTheme.gridColumns),
                contentPadding = PaddingValues(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
            ) {
                itemsIndexed(items) { index, item ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clickable { onItemClick(index) }
                    ) {
                        AsyncImage(
                            model = item.uri,
                            imageLoader = appImageLoader(context),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (item.isVideo) {
                            Text(
                                formatDuration(item.durationMs),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// Visualizzatore a schermo intero: si scorre tra foto e video.
// Le foto hanno il pulsante "Modifica", i video si riproducono.
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaViewerScreen(
    items: List<GalleryItem>,
    startIndex: Int,
    onBack: () -> Unit,
    onPageChanged: (Int) -> Unit,
    onEdit: (Uri) -> Unit
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = startIndex) { items.size }

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    val current = items.getOrNull(pagerState.currentPage)

    Box(modifier = Modifier.fillMaxSize().background(IosBlack)) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = items[page]
            if (item.isVideo) {
                VideoPage(item = item, isCurrent = page == pagerState.currentPage)
            } else {
                AsyncImage(
                    model = item.uri,
                    imageLoader = appImageLoader(context),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.5f))
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Indietro", tint = IosYellow)
            }
            Text(
                text = "${pagerState.currentPage + 1} di ${items.size}",
                color = Color.White,
                fontSize = 15.sp
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.5f))
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                val item = current ?: return@IconButton
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = if (item.isVideo) "video/mp4" else "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, item.uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    context.startActivity(Intent.createChooser(send, "Condividi"))
                } catch (_: Exception) {}
            }) {
                Icon(Icons.Default.Share, contentDescription = "Condividi", tint = Color.White)
            }

            if (current != null && !current.isVideo) {
                Button(
                    onClick = { onEdit(current.uri) },
                    colors = ButtonDefaults.buttonColors(containerColor = IosYellow),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = OnAccent)
                    Spacer(Modifier.width(8.dp))
                    Text("Modifica", color = OnAccent, fontWeight = FontWeight.Bold)
                }
            } else if (current != null) {
                Text(
                    "Video • " + formatDuration(current.durationMs),
                    color = Color.White,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// Pagina di un video: miniatura con "play", tocca per riprodurre
@Composable
fun VideoPage(item: GalleryItem, isCurrent: Boolean) {
    val context = LocalContext.current
    var playing by remember(item.uri) { mutableStateOf(false) }

    LaunchedEffect(isCurrent) {
        if (!isCurrent) playing = false
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (playing) {
            AndroidView(
                factory = { ctx ->
                    VideoView(ctx).apply {
                        val controller = MediaController(ctx)
                        controller.setAnchorView(this)
                        setMediaController(controller)
                        tag = controller
                        setVideoURI(item.uri)
                        setOnPreparedListener { start() }
                        setOnCompletionListener { playing = false }
                    }
                },
                onRelease = { view ->
                    (view.tag as? MediaController)?.hide()
                    view.stopPlayback()
                },
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            AsyncImage(
                model = item.uri,
                imageLoader = appImageLoader(context),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable { playing = true },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Riproduci",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }
    }
}

enum class ToolTab { ADJUST, FILTERS, CROP }

data class AdjustOption(
    val id: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun PhotoEditorScreen(uri: Uri, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previewSource by remember { mutableStateOf<Bitmap?>(null) }
    var editedPreview by remember { mutableStateOf<Bitmap?>(null) }
    var editParams by remember { mutableStateOf(EditParams()) }
    var showOriginalHold by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(ToolTab.ADJUST) }
    var selectedAdjustId by remember { mutableStateOf("brilliance") }
    var isSaving by remember { mutableStateOf(false) }

    // Il tasto "indietro" del telefono torna alla galleria invece di chiudere l'app
    BackHandler(enabled = !isSaving) { onBack() }

    val adjustOptions = remember {
        listOf(
            AdjustOption("exposure", "Esposizione", Icons.Default.Exposure),
            AdjustOption("brilliance", "Brillantezza", Icons.Default.AutoAwesome),
            AdjustOption("highlights", "Alte luci", Icons.Default.WbSunny),
            AdjustOption("shadows", "Ombre", Icons.Default.BrightnessLow),
            AdjustOption("contrast", "Contrasto", Icons.Default.Contrast),
            AdjustOption("saturation", "Saturazione", Icons.Default.Palette),
            AdjustOption("warmth", "Calore", Icons.Default.Thermostat)
        )
    }

    LaunchedEffect(uri) {
        val ok = withContext(Dispatchers.IO) {
            try {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                val full = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
                val scale = minOf(1400f / full.width, 1400f / full.height, 1f)
                val preview = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        full,
                        maxOf(1, (full.width * scale).toInt()),
                        maxOf(1, (full.height * scale).toInt()),
                        true
                    )
                } else full
                originalBitmap = full
                previewSource = preview
                true
            } catch (e: Throwable) {
                false
            }
        }
        if (!ok) {
            Toast.makeText(context, "Impossibile aprire questa foto", Toast.LENGTH_SHORT).show()
            onBack()
        }
    }

    LaunchedEffect(previewSource, editParams) {
        val src = previewSource ?: return@LaunchedEffect
        editedPreview = withContext(Dispatchers.Default) {
            ImageEngine.applyEdits(src, editParams)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Annulla",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onBack() }
            )

            if (editParams != EditParams()) {
                Text(
                    text = "Ripristina",
                    color = IosYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { editParams = EditParams() }
                )
            }

            Button(
                onClick = {
                    val full = originalBitmap ?: return@Button
                    isSaving = true
                    val params = editParams
                    scope.launch {
                        val saved = withContext(Dispatchers.IO) {
                            try {
                                val finalBmp = ImageEngine.applyEdits(full, params)
                                ImageEngine.saveToGallery(context, finalBmp) != null
                            } catch (e: Throwable) {
                                false
                            }
                        }
                        isSaving = false
                        if (saved) {
                            Toast.makeText(context, "Salvata nella Galleria", Toast.LENGTH_SHORT).show()
                            onSaved()
                        } else {
                            Toast.makeText(context, "Errore durante il salvataggio", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = IosYellow),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = if (isSaving) "..." else "Fine",
                    color = OnAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            showOriginalHold = true
                            tryAwaitRelease()
                            showOriginalHold = false
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            val displayBmp = if (showOriginalHold) previewSource else editedPreview
            displayBmp?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (showOriginalHold) {
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                ) {
                    Text(
                        "ORIGINALE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        when (activeTab) {
            ToolTab.ADJUST -> {
                val currentValue = getParamValue(editParams, selectedAdjustId)
                val currentLabel = adjustOptions.find { it.id == selectedAdjustId }?.label ?: ""

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        items(adjustOptions) { opt ->
                            val value = getParamValue(editParams, opt.id)
                            val isSelected = opt.id == selectedAdjustId
                            val isModified = value != 0f

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable { selectedAdjustId = opt.id }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color.White else IosDarkGray)
                                        .border(
                                            width = if (isModified && !isSelected) 2.dp else 0.dp,
                                            color = if (isModified) IosYellow else Color.Transparent,
                                            shape = CircleShape
                                        )
                                ) {
                                    Icon(
                                        imageVector = opt.icon,
                                        contentDescription = opt.label,
                                        tint = if (isSelected) Color.Black else Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = if (isModified) "${value.roundToInt()}" else opt.label,
                                    color = if (isSelected) IosYellow else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Text(
                        text = "${currentLabel.uppercase()}  ${currentValue.roundToInt()}",
                        color = if (currentValue != 0f) IosYellow else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IosRulerSlider(
                        value = currentValue,
                        onValueChange = { newVal ->
                            editParams = updateParamValue(editParams, selectedAdjustId, newVal)
                        }
                    )
                }
            }

            ToolTab.FILTERS -> {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(ImageEngine.filterNames) { index, name ->
                        val selected = editParams.filterIndex == index
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                editParams = editParams.copy(filterIndex = index)
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(IosDarkGray)
                                    .border(
                                        width = if (selected) 2.dp else 0.dp,
                                        color = IosYellow,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = name.take(3).uppercase(),
                                    color = if (selected) IosYellow else Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = name,
                                color = if (selected) IosYellow else Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            ToolTab.CROP -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 26.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = {
                            editParams = editParams.copy(rotation = (editParams.rotation + 90f) % 360f)
                        }
                    ) {
                        Icon(Icons.Default.RotateRight, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Ruota 90°", color = Color.White)
                    }
                    OutlinedButton(
                        onClick = {
                            editParams = editParams.copy(flipHorizontal = !editParams.flipHorizontal)
                        }
                    ) {
                        Icon(Icons.Default.Flip, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Rifletti", color = Color.White)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BottomTabItem("Regola", Icons.Default.Tune, activeTab == ToolTab.ADJUST) {
                activeTab = ToolTab.ADJUST
            }
            BottomTabItem("Filtri", Icons.Default.FilterVintage, activeTab == ToolTab.FILTERS) {
                activeTab = ToolTab.FILTERS
            }
            BottomTabItem("Ritaglia", Icons.Default.CropRotate, activeTab == ToolTab.CROP) {
                activeTab = ToolTab.CROP
            }
        }
    }
}

@Composable
fun BottomTabItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) IosYellow else Color.Gray)
        Spacer(Modifier.height(2.dp))
        Text(label, color = if (selected) IosYellow else Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun IosRulerSlider(value: Float, onValueChange: (Float) -> Unit) {
    val currentVal by rememberUpdatedState(value)
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 24.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    val delta = (dragAmount / size.width) * 200f
                    onValueChange((currentVal + delta).coerceIn(-100f, 100f))
                }
            }
    ) {
        val centerX = size.width / 2f
        val step = size.width / 40f
        val offsetPx = (value / 100f) * (size.width / 2.2f)

        for (i in -20..20) {
            val x = centerX + (i * step) + offsetPx
            if (x in 0f..size.width) {
                val isMajor = i % 5 == 0
                drawLine(
                    color = if (i == 0) IosYellow else Color.DarkGray,
                    start = Offset(x, if (isMajor) 14f else 22f),
                    end = Offset(x, size.height - 14f),
                    strokeWidth = if (i == 0) 4f else 2f
                )
            }
        }
        drawLine(
            color = Color.White,
            start = Offset(centerX, 6f),
            end = Offset(centerX, size.height - 6f),
            strokeWidth = 5f
        )
    }
}

private fun getParamValue(p: EditParams, id: String): Float = when (id) {
    "exposure" -> p.exposure
    "brilliance" -> p.brilliance
    "highlights" -> p.highlights
    "shadows" -> p.shadows
    "contrast" -> p.contrast
    "saturation" -> p.saturation
    "warmth" -> p.warmth
    else -> 0f
}

private fun updateParamValue(p: EditParams, id: String, v: Float): EditParams = when (id) {
    "exposure" -> p.copy(exposure = v)
    "brilliance" -> p.copy(brilliance = v)
    "highlights" -> p.copy(highlights = v)
    "shadows" -> p.copy(shadows = v)
    "contrast" -> p.copy(contrast = v)
    "saturation" -> p.copy(saturation = v)
    "warmth" -> p.copy(warmth = v)
    else -> p
}


// ===== Permessi =====
private val ALL_PERMISSIONS = arrayOf(
    Manifest.permission.CAMERA,
    Manifest.permission.RECORD_AUDIO,
    Manifest.permission.READ_MEDIA_IMAGES,
    Manifest.permission.READ_MEDIA_VIDEO,
    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
)

private fun hasCameraPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

// ===== Caricatore di immagini che sa fare anche le miniature dei video =====
private object AppImages {
    private var loader: ImageLoader? = null

    fun get(context: Context): ImageLoader {
        loader?.let { return it }
        val created = ImageLoader.Builder(context.applicationContext)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()
        loader = created
        return created
    }
}

fun appImageLoader(context: Context): ImageLoader = AppImages.get(context)

// ===== Legge foto e video dalla galleria, dal più recente =====
// Senza permessi della galleria vede comunque le foto/video fatti con questa app.
private fun loadGalleryItems(context: Context): List<GalleryItem> {
    val result = mutableListOf<GalleryItem>()
    val filesUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
    val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.MEDIA_TYPE,
        MediaStore.MediaColumns.DURATION
    )
    val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
    val args = arrayOf(
        MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
        MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
    )
    val sortOrder = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
    try {
        context.contentResolver.query(filesUri, projection, selection, args, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val typeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val durCol = cursor.getColumnIndex(MediaStore.MediaColumns.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val isVideo = cursor.getInt(typeCol) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                val uri = if (isVideo) {
                    ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                } else {
                    ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                }
                result.add(GalleryItem(uri, isVideo, duration))
            }
        }
    } catch (_: Exception) {
    }
    return result
}
