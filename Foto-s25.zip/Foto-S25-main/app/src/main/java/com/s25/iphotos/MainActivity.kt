package com.s25.iphotos

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// I colori (IosYellow, IosBlack, ...) sono in Tema.kt e si cambiano dalle impostazioni

// Una foto o un video della galleria
data class GalleryItem(val uri: Uri, val isVideo: Boolean, val durationMs: Long, val dateMs: Long = 0L)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        AppTheme.load(this)
        // Lo schermo resta acceso mentre si usa la fotocamera
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = IosBlack, surface = IosDarkGray)) {
                IPhotosApp()
            }
        }
    }
}

// Schermate dell'app
private const val SCR_CAMERA = "camera"
private const val SCR_GRID = "grid"
private const val SCR_VIEWER = "viewer"
private const val SCR_EDITOR = "editor"

@Composable
fun IPhotosApp() {
    val context = LocalContext.current
    var hasCamera by remember { mutableStateOf(hasCameraPermission(context)) }
    var items by remember { mutableStateOf<List<GalleryItem>>(emptyList()) }
    var refreshKey by remember { mutableStateOf(0) }

    var screen by rememberSaveable { mutableStateOf(SCR_CAMERA) }
    var viewerIndex by rememberSaveable { mutableStateOf(0) }
    var editUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var editFrom by rememberSaveable { mutableStateOf(SCR_VIEWER) }

    // Chiede tutti i permessi all'avvio: fotocamera, microfono e galleria
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        hasCamera = hasCameraPermission(context)
        refreshKey++
    }

    // Eliminazione: Android mostra la sua finestra di conferma
    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            Toast.makeText(context, "Eliminato", Toast.LENGTH_SHORT).show()
        }
        refreshKey++
    }
    val requestDelete: (List<Uri>) -> Unit = { uris ->
        if (uris.isNotEmpty()) {
            try {
                val pending = MediaStore.createDeleteRequest(context.contentResolver, uris)
                deleteLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
            } catch (e: Exception) {
                Toast.makeText(context, "Impossibile eliminare", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        if (ALL_PERMISSIONS.any {
                ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
            }) {
            launcher.launch(ALL_PERMISSIONS)
        }
    }

    LaunchedEffect(refreshKey) {
        items = withContext(Dispatchers.IO) { loadGalleryItems(context) }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = IosBlack) {
        when (screen) {
            SCR_GRID -> {
                GalleryGridScreen(
                    items = items,
                    onBack = { screen = SCR_CAMERA },
                    onItemClick = { index ->
                        viewerIndex = index
                        screen = SCR_VIEWER
                    },
                    onDelete = requestDelete,
                    onEdit = { uri ->
                        editUri = uri
                        editFrom = SCR_GRID
                        screen = SCR_EDITOR
                    }
                )
            }

            SCR_VIEWER -> {
                BackHandler { screen = SCR_GRID }
                if (items.isEmpty()) {
                    LaunchedEffect(Unit) { screen = SCR_GRID }
                } else {
                    MediaViewerScreen(
                        items = items,
                        startIndex = viewerIndex.coerceIn(0, items.size - 1),
                        onBack = { screen = SCR_GRID },
                        onPageChanged = { viewerIndex = it },
                        onEdit = { uri ->
                            editUri = uri
                            editFrom = SCR_VIEWER
                            screen = SCR_EDITOR
                        },
                        onDelete = { uri -> requestDelete(listOf(uri)) }
                    )
                }
            }

            SCR_EDITOR -> {
                val uri = editUri
                if (uri == null) {
                    LaunchedEffect(Unit) { screen = editFrom }
                } else {
                    PhotoEditorScreen(
                        uri = uri,
                        onBack = { screen = editFrom },
                        onSaved = {
                            // La foto modificata è la più recente: la mostra subito
                            viewerIndex = 0
                            refreshKey++
                            screen = SCR_VIEWER
                        }
                    )
                }
            }

            else -> {
                if (!hasCamera) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Button(
                            onClick = { launcher.launch(ALL_PERMISSIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = IosBlue)
                        ) {
                            Text("Consenti accesso alla fotocamera", color = Color.White)
                        }
                    }
                } else {
                    CameraScreen(
                        lastItem = items.firstOrNull(),
                        onOpenGallery = { screen = SCR_GRID },
                        onCaptured = { refreshKey++ }
                    )
                }
            }
        }
    }
}

// ===== Azioni comuni: condividi e "Apri con..." =====
fun shareItems(context: Context, list: List<GalleryItem>) {
    if (list.isEmpty()) return
    val intent = if (list.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = if (list[0].isVideo) "video/*" else "image/*"
            putExtra(Intent.EXTRA_STREAM, list[0].uri)
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = when {
                list.all { it.isVideo } -> "video/*"
                list.none { it.isVideo } -> "image/*"
                else -> "*/*"
            }
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(list.map { it.uri }))
        }
    }
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        context.startActivity(Intent.createChooser(intent, "Condividi"))
    } catch (_: Exception) {
    }
}

fun openWith(context: Context, item: GalleryItem) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(item.uri, if (item.isVideo) "video/*" else "image/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(Intent.createChooser(intent, "Apri con"))
    } catch (_: Exception) {
        Toast.makeText(context, "Nessuna app disponibile", Toast.LENGTH_SHORT).show()
    }
}

// Tutte le foto e i video in griglia.
// Tieni premuto su un elemento (o tocca "Seleziona") per sceglierne più d'uno
// ed eliminarli, condividerli o modificarli.
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryGridScreen(
    items: List<GalleryItem>,
    onBack: () -> Unit,
    onItemClick: (Int) -> Unit,
    onDelete: (List<Uri>) -> Unit,
    onEdit: (Uri) -> Unit
) {
    val context = LocalContext.current
    var selectionMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Uri>()) }

    // Toglie dalla selezione ciò che non esiste più (es. dopo l'eliminazione)
    LaunchedEffect(items) {
        val existing = items.map { it.uri }.toSet()
        selected = selected.filter { it in existing }.toSet()
    }

    fun exitSelection() {
        selectionMode = false
        selected = emptySet()
    }

    BackHandler { if (selectionMode) exitSelection() else onBack() }

    val selectedItems = items.filter { it.uri in selected }
    val gridState = rememberLazyGridState()

    // Cambia la grandezza delle miniature (meno colonne = miniature più grandi)
    fun changeColumns(delta: Int) {
        val idx = GRID_COLUMN_OPTIONS.indexOf(AppTheme.gridColumns).let { if (it < 0) 2 else it }
        val newIdx = (idx + delta).coerceIn(0, GRID_COLUMN_OPTIONS.size - 1)
        AppTheme.gridColumns = GRID_COLUMN_OPTIONS[newIdx]
        AppTheme.save(context)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // ----- Barra in alto -----
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selectionMode) {
                    TextButton(onClick = { exitSelection() }) {
                        Text("Annulla", color = IosYellow)
                    }
                    Text(
                        text = if (selected.isEmpty()) "Seleziona elementi" else "${selected.size} selezionati",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        selected = if (selected.size == items.size) emptySet() else items.map { it.uri }.toSet()
                    }) {
                        Text(if (selected.size == items.size) "Nessuno" else "Tutti", color = IosYellow)
                    }
                } else {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = "Fotocamera", tint = IosYellow)
                    }
                    Text(
                        text = "Libreria",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    // Miniature più piccole / più grandi
                    IconButton(onClick = { changeColumns(+1) }) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Miniature più piccole", tint = Color.White)
                    }
                    IconButton(onClick = { changeColumns(-1) }) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Miniature più grandi", tint = Color.White)
                    }
                    if (items.isNotEmpty()) {
                        TextButton(onClick = { selectionMode = true }) {
                            Text("Seleziona", color = IosYellow, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nessuna foto o video", color = Color.Gray)
                }
            } else {
              Box(modifier = Modifier.fillMaxSize()) {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Fixed(AppTheme.gridColumns),
                    contentPadding = PaddingValues(bottom = if (selectionMode) 110.dp else 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .navigationBarsPadding()
                        // Pizzica con due dita: allarga = miniature più grandi, stringi = più piccole.
                        // Con un dito solo la griglia scorre normalmente.
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                var scale = 1f
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    if (event.changes.count { it.pressed } >= 2) {
                                        scale *= event.calculateZoom()
                                        event.changes.forEach { it.consume() }
                                        if (scale > 1.3f) {
                                            changeColumns(-1)
                                            scale = 1f
                                        } else if (scale < 0.77f) {
                                            changeColumns(+1)
                                            scale = 1f
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                ) {
                    itemsIndexed(items) { index, item ->
                        val isSel = item.uri in selected
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .combinedClickable(
                                    onClick = {
                                        if (selectionMode) {
                                            selected = if (isSel) selected - item.uri else selected + item.uri
                                        } else {
                                            onItemClick(index)
                                        }
                                    },
                                    onLongClick = {
                                        selectionMode = true
                                        selected = selected + item.uri
                                    }
                                )
                        ) {
                            AsyncImage(
                                model = item.uri,
                                imageLoader = appImageLoader(context),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (item.isVideo) {
                                Text(
                                    formatDuration(item.durationMs),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(4.dp)
                                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                            if (selectionMode) {
                                if (isSel) {
                                    Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.25f)))
                                }
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(6.dp)
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(if (isSel) IosYellow else Color.Black.copy(alpha = 0.3f))
                                        .border(1.5.dp, Color.White, CircleShape)
                                ) {
                                    if (isSel) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = OnAccent,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Indicatore per scorrere velocemente
                FastScroller(
                    state = gridState,
                    itemCount = items.size,
                    labelFor = { idx -> monthLabel(items.getOrNull(idx)?.dateMs ?: 0L) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .fillMaxHeight()
                        .navigationBarsPadding()
                        .padding(bottom = if (selectionMode) 110.dp else 24.dp)
                )
              }
            }
        }

        // ----- Barra delle azioni (in modalità selezione) -----
        if (selectionMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(IosDarkGray)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ActionButton(Icons.Default.Share, "Condividi", enabled = selectedItems.isNotEmpty()) {
                    shareItems(context, selectedItems)
                }
                ActionButton(
                    Icons.Default.Edit,
                    "Modifica",
                    enabled = selectedItems.size == 1 && !selectedItems[0].isVideo
                ) {
                    val one = selectedItems.firstOrNull() ?: return@ActionButton
                    exitSelection()
                    onEdit(one.uri)
                }
                ActionButton(
                    Icons.Default.OpenInNew,
                    "Apri con",
                    enabled = selectedItems.size == 1
                ) {
                    selectedItems.firstOrNull()?.let { openWith(context, it) }
                }
                ActionButton(
                    Icons.Default.Delete,
                    "Elimina",
                    enabled = selectedItems.isNotEmpty(),
                    tint = Color(0xFFFF453A)
                ) {
                    onDelete(selectedItems.map { it.uri })
                }
            }
        }
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    val color = if (enabled) tint else Color.Gray.copy(alpha = 0.5f)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = color)
        Spacer(Modifier.height(2.dp))
        Text(label, color = color, fontSize = 11.sp)
    }
}

// Visualizzatore a schermo intero: si scorre tra foto e video.
// In basso: Condividi, Apri con, Modifica (foto) ed Elimina.
// I video partono da soli appena aperti, con un unico lettore già pronto.
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaViewerScreen(
    items: List<GalleryItem>,
    startIndex: Int,
    onBack: () -> Unit,
    onPageChanged: (Int) -> Unit,
    onEdit: (Uri) -> Unit,
    onDelete: (Uri) -> Unit
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = startIndex) { items.size }
    val current = items.getOrNull(pagerState.currentPage)

    // Un solo lettore video per tutto il visualizzatore (crearlo ogni volta è lento)
    val player = remember { buildFastPlayer(context) }
    var activeVideo by remember { mutableStateOf<GalleryItem?>(null) }
    var firstFrameShown by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onRenderedFirstFrame() {
                firstFrameShown = true
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(context, "Il video non si apre qui: scegli un'app", Toast.LENGTH_LONG).show()
                activeVideo?.let { openWith(context, it) }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    // Appena la pagina mostrata è un video: carica e parte subito
    LaunchedEffect(current?.uri) {
        val c = current
        if (c != null && c.isVideo) {
            firstFrameShown = false
            activeVideo = c
            player.setMediaItem(MediaItem.fromUri(c.uri))
            player.prepare()
            player.playWhenReady = true
        } else {
            activeVideo = null
            player.stop()
            player.clearMediaItems()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(IosBlack)) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = items[page]
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                val isActiveVideo = item.isVideo && activeVideo?.uri == item.uri
                if (isActiveVideo) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                this.player = player
                                useController = true
                                setBackgroundColor(android.graphics.Color.BLACK)
                            }
                        },
                        onRelease = { view -> view.player = null },
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(vertical = 56.dp)
                    )
                }
                // Miniatura: per le foto è l'immagine, per i video copre il nero
                // finché non compare il primo fotogramma
                if (!item.isVideo || !isActiveVideo || !firstFrameShown) {
                    AsyncImage(
                        model = item.uri,
                        imageLoader = appImageLoader(context),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(vertical = if (item.isVideo) 56.dp else 0.dp)
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.5f))
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBackIosNew, contentDescription = "Indietro", tint = IosYellow)
            }
            Text(
                text = "${pagerState.currentPage + 1} di ${items.size}" +
                    if (current?.isVideo == true) "  •  Video " + formatDuration(current.durationMs) else "",
                color = Color.White,
                fontSize = 15.sp
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.55f))
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ActionButton(Icons.Default.Share, "Condividi", enabled = current != null) {
                current?.let { shareItems(context, listOf(it)) }
            }
            ActionButton(Icons.Default.OpenInNew, "Apri con", enabled = current != null) {
                current?.let {
                    player.pause()
                    openWith(context, it)
                }
            }
            ActionButton(
                Icons.Default.Edit,
                "Modifica",
                enabled = current != null && !current.isVideo,
                tint = IosYellow
            ) {
                current?.let { onEdit(it.uri) }
            }
            ActionButton(
                Icons.Default.Delete,
                "Elimina",
                enabled = current != null,
                tint = Color(0xFFFF453A)
            ) {
                current?.let {
                    player.pause()
                    onDelete(it.uri)
                }
            }
        }
    }
}

// Lettore che parte quasi subito: aspetta solo 0,15 secondi di video
// invece dei 2,5 secondi normali (i file sono sul telefono, non serve di più)
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
private fun buildFastPlayer(context: Context): ExoPlayer {
    val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(1000, 30000, 150, 300)
        .build()
    return ExoPlayer.Builder(context)
        .setLoadControl(loadControl)
        .build()
}

enum class ToolTab { ADJUST, FILTERS, CROP }

data class AdjustOption(
    val id: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun PhotoEditorScreen(uri: Uri, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previewSource by remember { mutableStateOf<Bitmap?>(null) }
    var editedPreview by remember { mutableStateOf<Bitmap?>(null) }
    var editParams by remember { mutableStateOf(EditParams()) }
    var showOriginalHold by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(ToolTab.ADJUST) }
    var selectedAdjustId by remember { mutableStateOf("brilliance") }
    var isSaving by remember { mutableStateOf(false) }

    // Il tasto "indietro" del telefono torna alla galleria invece di chiudere l'app
    BackHandler(enabled = !isSaving) { onBack() }

    val adjustOptions = remember {
        listOf(
            AdjustOption("exposure", "Esposizione", Icons.Default.Exposure),
            AdjustOption("brilliance", "Brillantezza", Icons.Default.AutoAwesome),
            AdjustOption("highlights", "Alte luci", Icons.Default.WbSunny),
            AdjustOption("shadows", "Ombre", Icons.Default.BrightnessLow),
            AdjustOption("contrast", "Contrasto", Icons.Default.Contrast),
            AdjustOption("saturation", "Saturazione", Icons.Default.Palette),
            AdjustOption("warmth", "Calore", Icons.Default.Thermostat)
        )
    }

    LaunchedEffect(uri) {
        val ok = withContext(Dispatchers.IO) {
            try {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                val full = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
                val scale = minOf(1400f / full.width, 1400f / full.height, 1f)
                val preview = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        full,
                        maxOf(1, (full.width * scale).toInt()),
                        maxOf(1, (full.height * scale).toInt()),
                        true
                    )
                } else full
                originalBitmap = full
                previewSource = preview
                true
            } catch (e: Throwable) {
                false
            }
        }
        if (!ok) {
            Toast.makeText(context, "Impossibile aprire questa foto", Toast.LENGTH_SHORT).show()
            onBack()
        }
    }

    LaunchedEffect(previewSource, editParams) {
        val src = previewSource ?: return@LaunchedEffect
        editedPreview = withContext(Dispatchers.Default) {
            ImageEngine.applyEdits(src, editParams)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Annulla",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onBack() }
            )

            if (editParams != EditParams()) {
                Text(
                    text = "Ripristina",
                    color = IosYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { editParams = EditParams() }
                )
            }

            Button(
                onClick = {
                    val full = originalBitmap ?: return@Button
                    isSaving = true
                    val params = editParams
                    scope.launch {
                        val saved = withContext(Dispatchers.IO) {
                            try {
                                val finalBmp = ImageEngine.applyEdits(full, params)
                                ImageEngine.saveToGallery(context, finalBmp) != null
                            } catch (e: Throwable) {
                                false
                            }
                        }
                        isSaving = false
                        if (saved) {
                            Toast.makeText(context, "Salvata nella Galleria", Toast.LENGTH_SHORT).show()
                            onSaved()
                        } else {
                            Toast.makeText(context, "Errore durante il salvataggio", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = IosYellow),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = if (isSaving) "..." else "Fine",
                    color = OnAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            showOriginalHold = true
                            tryAwaitRelease()
                            showOriginalHold = false
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            val displayBmp = if (showOriginalHold) previewSource else editedPreview
            displayBmp?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (showOriginalHold) {
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                ) {
                    Text(
                        "ORIGINALE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        when (activeTab) {
            ToolTab.ADJUST -> {
                val currentValue = getParamValue(editParams, selectedAdjustId)
                val currentLabel = adjustOptions.find { it.id == selectedAdjustId }?.label ?: ""

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        items(adjustOptions) { opt ->
                            val value = getParamValue(editParams, opt.id)
                            val isSelected = opt.id == selectedAdjustId
                            val isModified = value != 0f

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable { selectedAdjustId = opt.id }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color.White else IosDarkGray)
                                        .border(
                                            width = if (isModified && !isSelected) 2.dp else 0.dp,
                                            color = if (isModified) IosYellow else Color.Transparent,
                                            shape = CircleShape
                                        )
                                ) {
                                    Icon(
                                        imageVector = opt.icon,
                                        contentDescription = opt.label,
                                        tint = if (isSelected) Color.Black else Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = if (isModified) "${value.roundToInt()}" else opt.label,
                                    color = if (isSelected) IosYellow else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Text(
                        text = "${currentLabel.uppercase()}  ${currentValue.roundToInt()}",
                        color = if (currentValue != 0f) IosYellow else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IosRulerSlider(
                        value = currentValue,
                        onValueChange = { newVal ->
                            editParams = updateParamValue(editParams, selectedAdjustId, newVal)
                        }
                    )
                }
            }

            ToolTab.FILTERS -> {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(ImageEngine.filterNames) { index, name ->
                        val selected = editParams.filterIndex == index
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                editParams = editParams.copy(filterIndex = index)
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(IosDarkGray)
                                    .border(
                                        width = if (selected) 2.dp else 0.dp,
                                        color = IosYellow,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = name.take(3).uppercase(),
                                    color = if (selected) IosYellow else Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = name,
                                color = if (selected) IosYellow else Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            ToolTab.CROP -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 26.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = {
                            editParams = editParams.copy(rotation = (editParams.rotation + 90f) % 360f)
                        }
                    ) {
                        Icon(Icons.Default.RotateRight, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Ruota 90°", color = Color.White)
                    }
                    OutlinedButton(
                        onClick = {
                            editParams = editParams.copy(flipHorizontal = !editParams.flipHorizontal)
                        }
                    ) {
                        Icon(Icons.Default.Flip, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Rifletti", color = Color.White)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BottomTabItem("Regola", Icons.Default.Tune, activeTab == ToolTab.ADJUST) {
                activeTab = ToolTab.ADJUST
            }
            BottomTabItem("Filtri", Icons.Default.FilterVintage, activeTab == ToolTab.FILTERS) {
                activeTab = ToolTab.FILTERS
            }
            BottomTabItem("Ritaglia", Icons.Default.CropRotate, activeTab == ToolTab.CROP) {
                activeTab = ToolTab.CROP
            }
        }
    }
}

@Composable
fun BottomTabItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) IosYellow else Color.Gray)
        Spacer(Modifier.height(2.dp))
        Text(label, color = if (selected) IosYellow else Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun IosRulerSlider(value: Float, onValueChange: (Float) -> Unit) {
    val currentVal by rememberUpdatedState(value)
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 24.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    val delta = (dragAmount / size.width) * 200f
                    onValueChange((currentVal + delta).coerceIn(-100f, 100f))
                }
            }
    ) {
        val centerX = size.width / 2f
        val step = size.width / 40f
        val offsetPx = (value / 100f) * (size.width / 2.2f)

        for (i in -20..20) {
            val x = centerX + (i * step) + offsetPx
            if (x in 0f..size.width) {
                val isMajor = i % 5 == 0
                drawLine(
                    color = if (i == 0) IosYellow else Color.DarkGray,
                    start = Offset(x, if (isMajor) 14f else 22f),
                    end = Offset(x, size.height - 14f),
                    strokeWidth = if (i == 0) 4f else 2f
                )
            }
        }
        drawLine(
            color = Color.White,
            start = Offset(centerX, 6f),
            end = Offset(centerX, size.height - 6f),
            strokeWidth = 5f
        )
    }
}

private fun getParamValue(p: EditParams, id: String): Float = when (id) {
    "exposure" -> p.exposure
    "brilliance" -> p.brilliance
    "highlights" -> p.highlights
    "shadows" -> p.shadows
    "contrast" -> p.contrast
    "saturation" -> p.saturation
    "warmth" -> p.warmth
    else -> 0f
}

private fun updateParamValue(p: EditParams, id: String, v: Float): EditParams = when (id) {
    "exposure" -> p.copy(exposure = v)
    "brilliance" -> p.copy(brilliance = v)
    "highlights" -> p.copy(highlights = v)
    "shadows" -> p.copy(shadows = v)
    "contrast" -> p.copy(contrast = v)
    "saturation" -> p.copy(saturation = v)
    "warmth" -> p.copy(warmth = v)
    else -> p
}


// ===== Permessi =====
private val ALL_PERMISSIONS = arrayOf(
    Manifest.permission.CAMERA,
    Manifest.permission.RECORD_AUDIO,
    Manifest.permission.READ_MEDIA_IMAGES,
    Manifest.permission.READ_MEDIA_VIDEO,
    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
)

private fun hasCameraPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

// ===== Caricatore di immagini che sa fare anche le miniature dei video =====
private object AppImages {
    private var loader: ImageLoader? = null

    fun get(context: Context): ImageLoader {
        loader?.let { return it }
        val created = ImageLoader.Builder(context.applicationContext)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()
        loader = created
        return created
    }
}

fun appImageLoader(context: Context): ImageLoader = AppImages.get(context)

// ===== Legge foto e video dalla galleria, dal più recente =====
// Senza permessi della galleria vede comunque le foto/video fatti con questa app.
private fun loadGalleryItems(context: Context): List<GalleryItem> {
    val result = mutableListOf<GalleryItem>()
    val filesUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
    val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.MEDIA_TYPE,
        MediaStore.MediaColumns.DURATION,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.Files.FileColumns.DATE_ADDED
    )
    val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
    val args = arrayOf(
        MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
        MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
    )
    val sortOrder = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
    try {
        context.contentResolver.query(filesUri, projection, selection, args, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val typeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val durCol = cursor.getColumnIndex(MediaStore.MediaColumns.DURATION)
            val takenCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
            val addedCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val isVideo = cursor.getInt(typeCol) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                val uri = if (isVideo) {
                    ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                } else {
                    ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                }
                val taken = if (takenCol >= 0 && !cursor.isNull(takenCol)) cursor.getLong(takenCol) else 0L
                val added = if (addedCol >= 0 && !cursor.isNull(addedCol)) cursor.getLong(addedCol) * 1000L else 0L
                result.add(GalleryItem(uri, isVideo, duration, if (taken > 0) taken else added))
            }
        }
    } catch (_: Exception) {
    }
    return result
}

// ===== Indicatore per scorrere velocemente la galleria =====
// Compare mentre si scorre; trascinandolo si salta in un punto qualsiasi
// e un'etichetta mostra il mese delle foto in quel punto.
@Composable
fun FastScroller(
    state: LazyGridState,
    itemCount: Int,
    labelFor: (Int) -> String,
    modifier: Modifier = Modifier
) {
    if (itemCount < 2) return
    val scope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableStateOf(0f) }
    var visible by remember { mutableStateOf(false) }

    // Si mostra mentre la griglia scorre o lo si trascina, poi sparisce
    LaunchedEffect(state.isScrollInProgress, dragging) {
        if (state.isScrollInProgress || dragging) {
            visible = true
        } else {
            delay(1500)
            visible = false
        }
    }
    val alpha by animateFloatAsState(if (visible) 1f else 0f, label = "scroller")

    val scrollFraction = state.firstVisibleItemIndex.toFloat() / (itemCount - 1).coerceAtLeast(1)
    val fraction = if (dragging) dragFraction else scrollFraction.coerceIn(0f, 1f)

    BoxWithConstraints(modifier = modifier.width(140.dp)) {
        val density = LocalDensity.current
        val thumbHeightPx = with(density) { 52.dp.toPx() }
        val trackPx = (constraints.maxHeight.toFloat() - thumbHeightPx).coerceAtLeast(1f)
        val thumbY = fraction * trackPx

        // Etichetta del mese, a sinistra del cursore, mentre lo si trascina
        if (dragging) {
            Text(
                labelFor((dragFraction * (itemCount - 1)).roundToInt()),
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset { IntOffset(0, (thumbY + thumbHeightPx / 4f).roundToInt()) }
                    .padding(end = 46.dp)
                    .background(IosDarkGray, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }

        // Cursore
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset { IntOffset(0, thumbY.roundToInt()) }
                .padding(end = 4.dp)
                .size(width = 34.dp, height = 52.dp)
                .alpha(alpha)
                .clip(RoundedCornerShape(17.dp))
                .background(if (dragging) IosYellow else IosDarkGray.copy(alpha = 0.92f))
                .pointerInput(itemCount) {
                    detectVerticalDragGestures(
                        onDragStart = {
                            dragging = true
                            visible = true
                            dragFraction = fraction
                        },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false }
                    ) { change, dy ->
                        change.consume()
                        dragFraction = (dragFraction + dy / trackPx).coerceIn(0f, 1f)
                        val target = (dragFraction * (itemCount - 1)).roundToInt()
                        scope.launch { state.scrollToItem(target) }
                    }
                }
        ) {
            Icon(
                Icons.Default.UnfoldMore,
                contentDescription = "Scorri velocemente",
                tint = if (dragging) OnAccent else Color.White
            )
        }
    }
}

// Data -> "Novembre 2026"
fun monthLabel(ms: Long): String {
    if (ms <= 0L) return ""
    val text = SimpleDateFormat("MMMM yyyy", Locale.ITALIAN).format(Date(ms))
    return text.replaceFirstChar { it.uppercase() }
}
