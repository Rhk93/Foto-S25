package com.s25.iphotos

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

// ===== Opzioni di personalizzazione del pulsante di scatto =====
val SHUTTER_COLORS = listOf(
    Color.White,
    Color(0xFFFFD60A),
    Color(0xFFFF453A),
    Color(0xFF0A84FF),
    Color(0xFF30D158),
    Color(0xFFFF6EC7),
    Color(0xFFBF5AF2)
)
val SHUTTER_COLOR_NAMES = listOf("Bianco", "Giallo", "Rosso", "Blu", "Verde", "Rosa", "Viola")
val SHUTTER_STYLES = listOf("Classico", "Pieno", "Obiettivo")
val SHUTTER_SIZES = listOf("Piccolo", "Medio", "Grande")
val SHUTTER_ANIMS = listOf("Iride", "Iride grande", "Lampo", "Nessuna")

const val ANIM_IRIS = 0
const val ANIM_IRIS_FULL = 1
const val ANIM_FLASH = 2

private val SHUTTER_SIZE_DP = listOf(70, 82, 94)
private val RECORD_RED = Color(0xFFE53935)

// ===== Impostazioni che restano salvate anche chiudendo l'app =====
@Composable
fun rememberPrefInt(key: String, default: Int): MutableState<Int> {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("fotocamera", Context.MODE_PRIVATE) }
    val state = remember { mutableStateOf(prefs.getInt(key, default)) }
    LaunchedEffect(state.value) {
        prefs.edit().putInt(key, state.value).apply()
    }
    return state
}

/**
 * Disegna un'iride (diaframma) con 6 lamelle.
 * closed = 0 → completamente aperta (non si vede niente)
 * closed = 1 → completamente chiusa
 */
fun DrawScope.drawIris(
    center: Offset,
    radius: Float,
    closed: Float,
    bladeColor: Color,
    lineColor: Color
) {
    if (closed <= 0f) return
    val blades = 6
    val step = (2 * PI / blades).toFloat()
    val holeRadius = radius * (1f - closed.coerceIn(0f, 1f))
    val rotation = closed * (PI / 3).toFloat()

    val verts = (0 until blades).map { i ->
        val a = rotation + i * step
        Offset(center.x + holeRadius * cos(a), center.y + holeRadius * sin(a))
    }

    val circle = Path().apply { addOval(Rect(center, radius)) }
    val bladesArea = Path().apply {
        fillType = PathFillType.EvenOdd
        addOval(Rect(center, radius))
        if (holeRadius > 0.5f) {
            moveTo(verts[0].x, verts[0].y)
            for (i in 1 until blades) lineTo(verts[i].x, verts[i].y)
            close()
        }
    }

    clipPath(circle) {
        drawPath(bladesArea, bladeColor)
        // Bordi delle lamelle: partono dagli angoli del foro e vanno verso l'esterno
        for (i in 0 until blades) {
            val v = verts[i]
            val prev = verts[(i + blades - 1) % blades]
            var dx = v.x - prev.x
            var dy = v.y - prev.y
            val len = sqrt(dx * dx + dy * dy)
            if (len < 0.01f) {
                val a = rotation + i * step
                dx = cos(a)
                dy = sin(a)
            } else {
                dx /= len
                dy /= len
            }
            drawLine(
                color = lineColor,
                start = v,
                end = Offset(v.x + dx * radius * 2.2f, v.y + dy * radius * 2.2f),
                strokeWidth = max(1.5f, radius * 0.035f)
            )
        }
    }
}

/**
 * Pulsante di scatto personalizzabile.
 * irisProgress: avanzamento dell'animazione dell'iride (0 = aperta, 1 = chiusa)
 */
@Composable
fun ShutterButton(
    colorIndex: Int,
    styleIndex: Int,
    sizeIndex: Int,
    isVideo: Boolean,
    isRecording: Boolean,
    irisProgress: Float,
    onClick: () -> Unit
) {
    val sizeDp = SHUTTER_SIZE_DP.getOrElse(sizeIndex) { 82 }
    val fill = SHUTTER_COLORS.getOrElse(colorIndex) { Color.White }

    Canvas(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .clickable { onClick() }
    ) {
        val c = center
        val r = size.minDimension / 2f
        val ring = 4.dp.toPx()

        if (isVideo) {
            drawCircle(Color.White, radius = r - ring / 2f, center = c, style = Stroke(ring))
            if (isRecording) {
                val side = r * 0.8f
                drawRoundRect(
                    color = RECORD_RED,
                    topLeft = Offset(c.x - side / 2f, c.y - side / 2f),
                    size = Size(side, side),
                    cornerRadius = CornerRadius(side * 0.18f)
                )
            } else {
                drawCircle(RECORD_RED, radius = r - ring - 4.dp.toPx(), center = c)
            }
            return@Canvas
        }

        when (styleIndex) {
            1 -> { // Pieno
                drawCircle(fill, radius = r, center = c)
                drawIris(c, r, irisProgress, Color(0xFF1C1C1E), Color(0xFF8E8E93))
            }

            2 -> { // Obiettivo: sembra una lente con il diaframma sempre visibile
                drawCircle(Color(0xFF111111), radius = r, center = c)
                drawCircle(fill, radius = r - ring / 2f, center = c, style = Stroke(ring))
                val lens = r * 0.74f
                drawCircle(fill.copy(alpha = 0.30f), radius = lens, center = c)
                drawIris(
                    c, lens,
                    0.35f + irisProgress * 0.65f,
                    Color(0xFF2C2C2E),
                    fill.copy(alpha = 0.7f)
                )
            }

            else -> { // Classico: anello + cerchio pieno
                drawCircle(Color.White, radius = r - ring / 2f, center = c, style = Stroke(ring))
                val inner = r - ring - 4.dp.toPx()
                drawCircle(fill, radius = inner, center = c)
                drawIris(c, inner, irisProgress, Color(0xFF1C1C1E), Color(0xFF8E8E93))
            }
        }
    }
}
