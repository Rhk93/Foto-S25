package com.s25.iphotos

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaActionSound
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.abs

private const val MODE_PHOTO = 0
private const val MODE_VIDEO = 1

// Risoluzioni video disponibili nelle impostazioni
private val VIDEO_QUALITIES = listOf("HD 720p", "Full HD 1080p", "4K UHD")

private fun qualityFor(index: Int): Quality = when (index) {
    0 -> Quality.HD
    2 -> Quality.UHD
    else -> Quality.FHD
}

@SuppressLint("MissingPermission")
@Composable
fun CameraScreen(
    lastItem: GalleryItem?,
    onOpenGallery: () -> Unit,
    onCaptured: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val mainExecutor = remember { ContextCompat.getMainExecutor(context) }

    // Modalità e obiettivo
    var mode by rememberSaveable { mutableStateOf(MODE_PHOTO) }
    var useFrontCamera by rememberSaveable { mutableStateOf(false) }
    var torchOn by rememberSaveable { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var settingsPage by remember { mutableStateOf(0) } // 0 = fotocamera, 1 = pulsante

    // Impostazioni salvate (restano anche chiudendo l'app)
    var flashMode by rememberPrefInt("flash", ImageCapture.FLASH_MODE_OFF)
    var timerSeconds by rememberPrefInt("timer", 0)
    var gridPref by rememberPrefInt("griglia", 0)
    var videoQualityIndex by rememberPrefInt("qualita_video", 1)
    var audioPref by rememberPrefInt("audio", 1)
    var soundPref by rememberPrefInt("suono_scatto", 1)
    var shutterColor by rememberPrefInt("pulsante_colore", 0)
    var shutterStyle by rememberPrefInt("pulsante_stile", 0)
    var shutterSize by rememberPrefInt("pulsante_misura", 1)
    var shutterAnim by rememberPrefInt("pulsante_animazione", ANIM_IRIS)
    val showGrid = gridPref == 1
    val audioEnabled = audioPref == 1

    // Animazione dell'iride (0 = aperta, 1 = chiusa)
    val iris = remember { Animatable(0f) }
    // Suono di scatto di sistema
    val actionSound = remember { MediaActionSound().apply { load(MediaActionSound.SHUTTER_CLICK) } }

    // Stato della fotocamera
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var recordingSeconds by remember { mutableStateOf(0L) }
    var countdown by remember { mutableStateOf(0) }
    var shutterBlink by remember { mutableStateOf(false) }
    val vqIndex = videoQualityIndex.coerceIn(0, VIDEO_QUALITIES.size - 1)
    var zoomText by remember { mutableStateOf("") }

    val isRecording = recording != null
    val busy = isRecording || countdown > 0

    // Collega la fotocamera ogni volta che cambia modalità, obiettivo o risoluzione
    LaunchedEffect(mode, useFrontCamera, videoQualityIndex) {
        val provider = cameraProvider ?: getCameraProvider(context).also { cameraProvider = it }
        val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        try {
            provider.unbindAll()
            if (mode == MODE_PHOTO) {
                val ic = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(flashMode)
                    .build()
                camera = provider.bindToLifecycle(lifecycleOwner, selector, preview, ic)
                imageCapture = ic
                videoCapture = null
            } else {
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            qualityFor(vqIndex),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val vc = VideoCapture.withOutput(recorder)
                camera = provider.bindToLifecycle(lifecycleOwner, selector, preview, vc)
                videoCapture = vc
                imageCapture = null
                camera?.cameraControl?.enableTorch(torchOn)
            }
            zoomText = ""
        } catch (e: Exception) {
            Toast.makeText(context, "Errore fotocamera: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Spegne la fotocamera quando si esce da questa schermata
    DisposableEffect(Unit) {
        onDispose {
            recording?.stop()
            cameraProvider?.unbindAll()
            actionSound.release()
        }
    }

    // Cronometro della registrazione
    LaunchedEffect(isRecording) {
        recordingSeconds = 0
        while (isRecording) {
            delay(1000)
            recordingSeconds++
        }
    }

    // Lampo nero di conferma scatto
    LaunchedEffect(shutterBlink) {
        if (shutterBlink) {
            delay(120)
            shutterBlink = false
        }
    }

    fun takePhoto() {
        val ic = imageCapture ?: return
        ic.flashMode = flashMode
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "S25_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/Foto S25")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ).build()
        // Animazione e suono dello scatto
        if (soundPref == 1) actionSound.play(MediaActionSound.SHUTTER_CLICK)
        when (shutterAnim) {
            ANIM_IRIS, ANIM_IRIS_FULL -> scope.launch {
                iris.snapTo(0f)
                iris.animateTo(1f, tween(durationMillis = 130))
                delay(70)
                iris.animateTo(0f, tween(durationMillis = 260))
            }
            ANIM_FLASH -> shutterBlink = true
        }
        ic.takePicture(options, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                onCaptured()
            }

            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(context, "Errore nello scatto", Toast.LENGTH_SHORT).show()
            }
        })
    }

    fun startRecording() {
        val vc = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "S25_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/Foto S25")
        }
        val output = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = vc.output.prepareRecording(context, output)
        val canRecordAudio = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (audioEnabled && canRecordAudio) {
            pending = pending.withAudioEnabled()
        }
        if (soundPref == 1) actionSound.play(MediaActionSound.START_VIDEO_RECORDING)
        try {
            recording = pending.start(mainExecutor) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    recording = null
                    if (event.hasError()) {
                        Toast.makeText(context, "Errore nel video", Toast.LENGTH_SHORT).show()
                    } else {
                        onCaptured()
                    }
                }
            }
        } catch (e: Exception) {
            recording = null
            Toast.makeText(context, "Impossibile registrare", Toast.LENGTH_SHORT).show()
        }
    }

    fun onShutter() {
        if (mode == MODE_VIDEO) {
            if (isRecording) {
                if (soundPref == 1) actionSound.play(MediaActionSound.STOP_VIDEO_RECORDING)
                recording?.stop()
            } else {
                startRecording()
            }
        } else if (countdown == 0) {
            if (timerSeconds == 0) {
                takePhoto()
            } else {
                scope.launch {
                    countdown = timerSeconds
                    while (countdown > 0) {
                        delay(1000)
                        countdown--
                    }
                    takePhoto()
                }
            }
        }
    }

    fun applyZoom(factor: Float) {
        val cam = camera ?: return
        val state = cam.cameraInfo.zoomState.value ?: return
        val newRatio = (state.zoomRatio * factor).coerceIn(state.minZoomRatio, state.maxZoomRatio)
        cam.cameraControl.setZoomRatio(newRatio)
        zoomText = String.format("%.1fx", newRatio)
    }

    fun focusAt(offset: Offset) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
        cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // ===== ANTEPRIMA LIVE =====
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(top = 56.dp, bottom = 190.dp)
        ) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

            if (showGrid) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val c = Color.White.copy(alpha = 0.35f)
                    for (i in 1..2) {
                        val x = size.width * i / 3f
                        val y = size.height * i / 3f
                        drawLine(c, Offset(x, 0f), Offset(x, size.height), 2f)
                        drawLine(c, Offset(0f, y), Offset(size.width, y), 2f)
                    }
                }
            }

            // Gesti: scorri = cambia Foto/Video, pizzica = zoom, tocca = messa a fuoco
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(busy) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var totalX = 0f
                            var totalY = 0f
                            var multiTouch = false
                            do {
                                val event = awaitPointerEvent()
                                if (event.changes.size > 1) {
                                    multiTouch = true
                                    val zoom = event.calculateZoom()
                                    if (zoom != 1f) applyZoom(zoom)
                                } else {
                                    val change = event.changes.first().positionChange()
                                    totalX += change.x
                                    totalY += change.y
                                }
                            } while (event.changes.any { it.pressed })

                            if (!multiTouch) {
                                if (abs(totalX) < 25f && abs(totalY) < 25f) {
                                    focusAt(down.position)
                                } else if (!busy && abs(totalX) > 120f && abs(totalX) > abs(totalY)) {
                                    mode = if (totalX < 0) MODE_VIDEO else MODE_PHOTO
                                    showSettings = false
                                }
                            }
                        }
                    }
            )

            if (zoomText.isNotEmpty()) {
                Text(
                    zoomText,
                    color = IosYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            if (countdown > 0) {
                Text(
                    "$countdown",
                    color = Color.White,
                    fontSize = 96.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            if (shutterBlink) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f)))
            }

            // Iride grande su tutta l'anteprima (come i primi iPhone)
            if (shutterAnim == ANIM_IRIS_FULL && iris.value > 0f) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val diag = kotlin.math.sqrt(size.width * size.width + size.height * size.height)
                    drawIris(center, diag / 2f, iris.value, Color(0xFF151515), Color(0xFF4A4A4A))
                }
            }
        }

        // ===== BARRA IN ALTO =====
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(56.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (mode == MODE_PHOTO) {
                IconButton(onClick = {
                    flashMode = when (flashMode) {
                        ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                        ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                        else -> ImageCapture.FLASH_MODE_OFF
                    }
                    imageCapture?.flashMode = flashMode
                }) {
                    Icon(
                        when (flashMode) {
                            ImageCapture.FLASH_MODE_AUTO -> Icons.Default.FlashAuto
                            ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                            else -> Icons.Default.FlashOff
                        },
                        contentDescription = "Flash",
                        tint = if (flashMode == ImageCapture.FLASH_MODE_OFF) Color.White else IosYellow
                    )
                }
            } else {
                IconButton(onClick = {
                    torchOn = !torchOn
                    camera?.cameraControl?.enableTorch(torchOn)
                }) {
                    Icon(
                        if (torchOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                        contentDescription = "Torcia",
                        tint = if (torchOn) IosYellow else Color.White
                    )
                }
            }

            if (isRecording) {
                Text(
                    "● " + formatDuration(recordingSeconds * 1000),
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(Color(0xFFE53935), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            } else if (mode == MODE_VIDEO) {
                Text(
                    VIDEO_QUALITIES[vqIndex] + if (audioEnabled) "" else " • muto",
                    color = Color.White,
                    fontSize = 13.sp
                )
            } else if (timerSeconds > 0) {
                Text("Timer ${timerSeconds}s", color = IosYellow, fontSize = 13.sp)
            }

            IconButton(onClick = { if (!busy) showSettings = !showSettings }) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = "Impostazioni",
                    tint = if (showSettings) IosYellow else Color.White
                )
            }
        }

        // ===== PANNELLO IMPOSTAZIONI =====
        if (showSettings) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(top = 56.dp, start = 12.dp, end = 12.dp)
                    .heightIn(max = 460.dp)
                    .background(Color(0xEE1C1C1E), RoundedCornerShape(16.dp))
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                ChoiceRow(
                    listOf(if (mode == MODE_PHOTO) "Foto" else "Video", "Pulsante di scatto"),
                    settingsPage
                ) { settingsPage = it }
                Spacer(Modifier.height(14.dp))

                if (settingsPage == 1) {
                    // ----- Personalizzazione del pulsante -----
                    SettingLabel("Colore")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SHUTTER_COLORS.forEachIndexed { index, color ->
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (index == shutterColor) 3.dp else 1.dp,
                                        color = if (index == shutterColor) IosYellow else Color.Gray,
                                        shape = CircleShape
                                    )
                                    .clickable { shutterColor = index }
                            )
                        }
                    }
                    Text(
                        SHUTTER_COLOR_NAMES.getOrElse(shutterColor) { "" },
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Stile")
                    ChoiceRow(SHUTTER_STYLES, shutterStyle) { shutterStyle = it }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Dimensione")
                    ChoiceRow(SHUTTER_SIZES, shutterSize) { shutterSize = it }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Animazione di scatto")
                    ChoiceRow(SHUTTER_ANIMS, shutterAnim) { shutterAnim = it }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Suono di scatto")
                    ChoiceRow(listOf("Sì", "No"), if (soundPref == 1) 0 else 1) {
                        soundPref = if (it == 0) 1 else 0
                    }
                    Spacer(Modifier.height(14.dp))
                    // Prova: mostra l'animazione senza scattare
                    Text(
                        "▶ Prova animazione",
                        color = IosYellow,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable {
                                scope.launch {
                                    iris.snapTo(0f)
                                    iris.animateTo(1f, tween(durationMillis = 130))
                                    delay(70)
                                    iris.animateTo(0f, tween(durationMillis = 260))
                                }
                            }
                            .padding(vertical = 4.dp)
                    )
                } else if (mode == MODE_PHOTO) {
                    SettingLabel("Timer")
                    ChoiceRow(listOf("No", "3 s", "10 s"), listOf(0, 3, 10).indexOf(timerSeconds)) {
                        timerSeconds = listOf(0, 3, 10)[it]
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Flash")
                    ChoiceRow(
                        listOf("Spento", "Auto", "Acceso"),
                        when (flashMode) {
                            ImageCapture.FLASH_MODE_AUTO -> 1
                            ImageCapture.FLASH_MODE_ON -> 2
                            else -> 0
                        }
                    ) {
                        flashMode = when (it) {
                            1 -> ImageCapture.FLASH_MODE_AUTO
                            2 -> ImageCapture.FLASH_MODE_ON
                            else -> ImageCapture.FLASH_MODE_OFF
                        }
                        imageCapture?.flashMode = flashMode
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Griglia")
                    ChoiceRow(listOf("No", "Sì"), gridPref) { gridPref = it }
                } else {
                    SettingLabel("Risoluzione")
                    ChoiceRow(VIDEO_QUALITIES, vqIndex) { videoQualityIndex = it }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Audio")
                    ChoiceRow(listOf("Con audio", "Muto"), if (audioEnabled) 0 else 1) {
                        audioPref = if (it == 0) 1 else 0
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Torcia")
                    ChoiceRow(listOf("Spenta", "Accesa"), if (torchOn) 1 else 0) {
                        torchOn = it == 1
                        camera?.cameraControl?.enableTorch(torchOn)
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingLabel("Griglia")
                    ChoiceRow(listOf("No", "Sì"), gridPref) { gridPref = it }
                }
            }
        }

        // ===== PARTE IN BASSO =====
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Selettore FOTO / VIDEO (si può anche scorrere sull'anteprima)
            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                modifier = Modifier.padding(bottom = 18.dp)
            ) {
                ModeLabel("FOTO", mode == MODE_PHOTO) {
                    if (!busy) { mode = MODE_PHOTO; showSettings = false }
                }
                ModeLabel("VIDEO", mode == MODE_VIDEO) {
                    if (!busy) { mode = MODE_VIDEO; showSettings = false }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 36.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Anteprima dell'ultima foto/video: apre la galleria
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(IosDarkGray)
                        .border(2.dp, Color.White, CircleShape)
                        .clickable(enabled = !busy) { onOpenGallery() },
                    contentAlignment = Alignment.Center
                ) {
                    if (lastItem != null) {
                        AsyncImage(
                            model = lastItem.uri,
                            imageLoader = appImageLoader(context),
                            contentDescription = "Galleria",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = "Galleria", tint = Color.Gray)
                    }
                }

                // Pulsante di scatto / registrazione (personalizzabile)
                Box(modifier = Modifier.size(94.dp), contentAlignment = Alignment.Center) {
                    ShutterButton(
                        colorIndex = shutterColor,
                        styleIndex = shutterStyle,
                        sizeIndex = shutterSize,
                        isVideo = mode == MODE_VIDEO,
                        isRecording = isRecording,
                        irisProgress = if (shutterAnim == ANIM_IRIS || shutterAnim == ANIM_IRIS_FULL) iris.value else 0f,
                        onClick = { onShutter() }
                    )
                }

                // Cambia fotocamera (posteriore / frontale)
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(IosDarkGray)
                        .clickable(enabled = !busy) { useFrontCamera = !useFrontCamera },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Cameraswitch, contentDescription = "Cambia fotocamera", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun ModeLabel(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) IosYellow else Color.White,
        fontSize = 14.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 4.dp)
    )
}

@Composable
private fun SettingLabel(text: String) {
    Text(text, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
private fun ChoiceRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        options.forEachIndexed { index, label ->
            val isSel = index == selected
            Text(
                label,
                color = if (isSel) Color.Black else Color.White,
                fontSize = 13.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isSel) IosYellow else Color(0xFF3A3A3C))
                    .clickable { onSelect(index) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

private suspend fun getCameraProvider(context: Context): ProcessCameraProvider =
    suspendCoroutine { cont ->
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({ cont.resume(future.get()) }, ContextCompat.getMainExecutor(context))
    }

fun formatDuration(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return String.format("%02d:%02d", m, s)
}
